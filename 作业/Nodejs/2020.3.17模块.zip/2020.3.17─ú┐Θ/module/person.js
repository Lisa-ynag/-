function Person(name,age){
	this.name = name;
	this.age = age;
}
module.exports = Person;